import { AnalyticsPanels } from '@/components/forensics/analytics-panels'
import { DashboardHeader } from '@/components/forensics/dashboard-header'
import { FlowCanvas } from '@/components/forensics/flow-canvas'
import { InvestigationProvider } from '@/components/forensics/investigation-provider'
import { StatsStrip } from '@/components/forensics/stats-strip'
import { TimelineControl } from '@/components/forensics/timeline-control'

export default function Page() {
  return (
    <InvestigationProvider>
      <DashboardHeader />
      <main className="mx-auto flex max-w-[1600px] flex-col gap-4 px-4 py-4">
        <StatsStrip />
        <FlowCanvas />
        <TimelineControl />
        <AnalyticsPanels />
      </main>
    </InvestigationProvider>
  )
}
