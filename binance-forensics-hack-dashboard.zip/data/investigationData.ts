/**
 * Investigation dataset for the dashboard.
 *
 * Everything the UI renders is derived from the exports in this file:
 *  - `incident`     header copy + timeline block range
 *  - `entities`     canvas nodes (wallets, contracts, bridges, DEX pools, mixers)
 *  - `transfers`    canvas edges + event log rows (one row per on-chain tx)
 *  - `milestones`   flags on the timeline replay control
 *  - `assets`       Asset Breakdown table (unsecured is computed)
 *
 * `block` values on transfers/milestones use the Ethereum reference block so
 * that events across chains can share a single replay timeline.
 * Set `tally: false` on pass-through hops so they are not double counted in totals.
 */

export type Category = 'ingress' | 'frozen' | 'swapped' | 'seized' | 'mixer'
export type Chain = 'ethereum' | 'arbitrum' | 'bnb' | 'solana'
export type EntityKind =
  | 'exchange'
  | 'wallet'
  | 'contract'
  | 'protocol'
  | 'dex'
  | 'bridge'
  | 'mixer'
  | 'issuer'
  | 'vault'

export interface Entity {
  id: string
  label: string
  address: string
  kind: EntityKind
  chain: Chain
  category: Category
  position: { x: number; y: number }
  tags: string[]
  note: string
}

export interface Transfer {
  id: string
  source: string
  target: string
  txHash: string
  chain: Chain
  token: string
  amount: number
  valueUsd: number
  gasFee: number
  protocol: string
  method: string
  block: number
  category: Category
  tally?: boolean
  note?: string
}

export interface Milestone {
  id: string
  label: string
  block: number
  category: Category
  description: string
}

export interface AssetRow {
  token: string
  name: string
  priceUsd: number
  stolen: number
  converted: number
  frozen: number
  seized: number
}

export const incident = {
  name: 'Binance Forensics Hack',
  caseId: 'BFH-2026-1104',
  status: 'ACTIVE INVESTIGATION',
  dateLabel: 'NOV 04 2026',
  startBlock: 21847090,
  endBlock: 21849600,
  startTimestamp: '2026-11-04T02:41:11Z',
  secondsPerBlock: 12,
  leadAnalyst: 'Chain Forensics Unit',
}

export const ETH_PRICE_USD = 3600

export const nativeGas: Record<Chain, { symbol: string; priceUsd: number }> = {
  ethereum: { symbol: 'ETH', priceUsd: 3600 },
  arbitrum: { symbol: 'ETH', priceUsd: 3600 },
  bnb: { symbol: 'BNB', priceUsd: 640 },
  solana: { symbol: 'SOL', priceUsd: 210 },
}

export const chains: { id: Chain; label: string; short: string }[] = [
  { id: 'ethereum', label: 'Ethereum', short: 'ETH' },
  { id: 'arbitrum', label: 'Arbitrum', short: 'ARB' },
  { id: 'bnb', label: 'BNB Chain', short: 'BSC' },
  { id: 'solana', label: 'Solana', short: 'SOL' },
]

/** Swimlane bands drawn behind the nodes on the canvas. */
export const chainBands: { chain: Chain; y: number; height: number }[] = [
  { chain: 'ethereum', y: -70, height: 440 },
  { chain: 'arbitrum', y: 390, height: 160 },
  { chain: 'bnb', y: 570, height: 260 },
  { chain: 'solana', y: 850, height: 260 },
]
export const bandX = -70
export const bandWidth = 1940

export const entities: Entity[] = [
  {
    id: 'n1',
    label: 'Binance Hot Wallet 7',
    address: '0x9a1c7e04b3d58f2e6c0a41d7b8e95f3c2d6a7e10',
    kind: 'exchange',
    chain: 'ethereum',
    category: 'ingress',
    position: { x: 0, y: 20 },
    tags: ['Victim', 'Multisig 3/5'],
    note: 'Compromised hot wallet. Attacker replayed a forged multisig approval to drain ETH, USDT and USDC in three consecutive calls.',
  },
  {
    id: 'n4',
    label: 'Aave V3 Pool',
    address: '0x5c2e8a1f9b3d74e06a8c2f5b1d9e7a3c4f6b8d02',
    kind: 'protocol',
    chain: 'ethereum',
    category: 'ingress',
    position: { x: 0, y: 230 },
    tags: ['Flash Loan Source'],
    note: '45,000 WETH flash loan used to inflate the signer-quorum check. Loan repaid within the same transaction bundle.',
  },
  {
    id: 'n3',
    label: 'Exploit Contract',
    address: '0x1e8b4f7a2c9d05e63b7a1f8c4d2e9b6a3f05c7d1',
    kind: 'contract',
    chain: 'ethereum',
    category: 'ingress',
    position: { x: 320, y: 125 },
    tags: ['Unverified', 'Self-destructed'],
    note: 'Deployed 4 blocks before the exploit by Exploiter EOA 1. Bytecode contains a hardcoded sweep() to the exploiter EOA.',
  },
  {
    id: 'n2',
    label: 'Exploiter EOA 1',
    address: '0x7d4e2b9c1a8f63e05d92c7b4a1e8f3d6c9b20a57',
    kind: 'wallet',
    chain: 'ethereum',
    category: 'ingress',
    position: { x: 640, y: 125 },
    tags: ['Primary Attacker', 'Funded via Tornado'],
    note: 'Central distribution wallet. Split proceeds into DEX dumps, three bridge routes and Tornado Cash deposits.',
  },
  {
    id: 'n5',
    label: 'Uniswap V3 USDT/WETH',
    address: '0x2b6f9e3a7c1d84f05e9b2a6c8d3f1e7a4b5c9d63',
    kind: 'dex',
    chain: 'ethereum',
    category: 'swapped',
    position: { x: 960, y: -20 },
    tags: ['0.05% Pool'],
    note: 'Attacker market-sold USDT before issuer freeze, causing ~1.8% price impact on the pool.',
  },
  {
    id: 'n8',
    label: 'Tornado Cash Router',
    address: '0xd90e2f925da726b50c4ed8d0fb90ad053324f31b',
    kind: 'mixer',
    chain: 'ethereum',
    category: 'mixer',
    position: { x: 960, y: 125 },
    tags: ['Sanctioned', '100 ETH Pool'],
    note: '42 deposits of 100 ETH notes. Withdrawals clustered by timing and gas-price fingerprint.',
  },
  {
    id: 'n7',
    label: 'Tether USDT Contract',
    address: '0xdac17f958d2ee523a2206206994597c13d831ec7',
    kind: 'issuer',
    chain: 'ethereum',
    category: 'frozen',
    position: { x: 960, y: 270 },
    tags: ['Issuer Blacklist'],
    note: 'Tether executed addBlackList() on Exploiter EOA 1, freezing the remaining USDT balance.',
  },
  {
    id: 'n9',
    label: 'Mixer Hop Wallet',
    address: '0x6a3f1c8e5b9d27a04f6e3b8c1d7a5e9f2c4b0d81',
    kind: 'wallet',
    chain: 'ethereum',
    category: 'mixer',
    position: { x: 1280, y: 125 },
    tags: ['Heuristic Link 87%'],
    note: 'Linked to the attacker via Tornado withdrawal timing and a reused relayer. Confidence: high.',
  },
  {
    id: 'n18',
    label: 'DOJ Seizure Vault',
    address: '0xc4a7e2f9b1d63e85a0f7c3b9e2d4a6f1b8c5e073',
    kind: 'vault',
    chain: 'ethereum',
    category: 'seized',
    position: { x: 1600, y: 125 },
    tags: ['Court Order', 'Custodial'],
    note: 'Government-controlled custody address. Funds transferred under seizure warrant after hop-wallet key recovery.',
  },
  {
    id: 'n15',
    label: 'Arbitrum Delayed Inbox',
    address: '0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f',
    kind: 'bridge',
    chain: 'arbitrum',
    category: 'mixer',
    position: { x: 960, y: 428 },
    tags: ['Canonical Bridge'],
    note: 'ETH bridged to Arbitrum to access deeper Camelot liquidity.',
  },
  {
    id: 'n16',
    label: 'Exploiter ARB Wallet',
    address: '0x8f2d6b4a9e1c73f05b8a2e6d4c9f1b7a3e5d0c28',
    kind: 'wallet',
    chain: 'arbitrum',
    category: 'ingress',
    position: { x: 1280, y: 428 },
    tags: ['Same Key as EOA 1'],
    note: 'Same private key as Exploiter EOA 1 (address reuse across chains).',
  },
  {
    id: 'n17',
    label: 'Camelot Router',
    address: '0xc873fecbd354f5a56e00e710b90ef4201db2448d',
    kind: 'dex',
    chain: 'arbitrum',
    category: 'swapped',
    position: { x: 1600, y: 428 },
    tags: ['AMM'],
    note: 'ETH swapped into ARB and USDC across 6 transactions.',
  },
  {
    id: 'n11',
    label: 'Celer cBridge',
    address: '0x5427fefa711eff984124bfbb1ab6fbf5e3da1820',
    kind: 'bridge',
    chain: 'bnb',
    category: 'mixer',
    position: { x: 960, y: 660 },
    tags: ['Liquidity Bridge'],
    note: 'USDT moved to BNB Chain. Celer flagged and delayed the final relay by 18 blocks.',
  },
  {
    id: 'n13',
    label: 'Exploiter BSC Wallet',
    address: '0x3b9e7a1d5f2c84e06b9d3a7f1e5c8b2d4a6f9e17',
    kind: 'wallet',
    chain: 'bnb',
    category: 'ingress',
    position: { x: 1280, y: 660 },
    tags: ['KYC Deposit Hit'],
    note: 'Attempted deposit into a Binance account triggered compliance freeze and clawback.',
  },
  {
    id: 'n12',
    label: 'PancakeSwap V3 Router',
    address: '0x13f4ea83d0bd40e75c8222255bc855a974568dd4',
    kind: 'dex',
    chain: 'bnb',
    category: 'swapped',
    position: { x: 1600, y: 600 },
    tags: ['AMM'],
    note: 'USDT dumped for BNB before Binance compliance action.',
  },
  {
    id: 'n14',
    label: 'Binance Recovery Wallet',
    address: '0xe1f5b8d3a7c92e04f1b6d8a3c5e7f9b2d4a6c018',
    kind: 'vault',
    chain: 'bnb',
    category: 'seized',
    position: { x: 1600, y: 730 },
    tags: ['Recovered'],
    note: 'Funds rescued through internal ledger clawback after deposit attribution.',
  },
  {
    id: 'n19',
    label: 'Wormhole Token Bridge',
    address: '0x3ee18b2214aff97000d974cf647e7c347e8fa585',
    kind: 'bridge',
    chain: 'solana',
    category: 'mixer',
    position: { x: 960, y: 940 },
    tags: ['Guardian Network'],
    note: 'USDC bridged to Solana as wrapped-then-native USDC via CCTP route.',
  },
  {
    id: 'n20',
    label: 'Exploiter SOL Wallet',
    address: '9mF4qXzT2bLk8RvW3nYc6HdP1sJeA5uG7oKiZ4wQxB2N',
    kind: 'wallet',
    chain: 'solana',
    category: 'ingress',
    position: { x: 1280, y: 940 },
    tags: ['Fresh Account'],
    note: 'Created 2 slots before the bridge redeem. Funded with 0.05 SOL from a Jito tip account.',
  },
  {
    id: 'n21',
    label: 'Jupiter Aggregator',
    address: 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',
    kind: 'dex',
    chain: 'solana',
    category: 'swapped',
    position: { x: 1600, y: 880 },
    tags: ['Aggregator'],
    note: 'USDC routed through Orca and Raydium into SOL.',
  },
  {
    id: 'n22',
    label: 'Circle USDC (SPL Mint)',
    address: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    kind: 'issuer',
    chain: 'solana',
    category: 'frozen',
    position: { x: 1600, y: 1010 },
    tags: ['Issuer Freeze'],
    note: 'Circle froze the exploiter token account via freezeAccount authority.',
  },
]

export const transfers: Transfer[] = [
  {
    id: 't01',
    source: 'n4',
    target: 'n3',
    txHash: '0x4f9a2c7e1b8d63f05a9c2e7b4d1f8a3c6e9b2d05f7a1c4e8b3d6f9a2c5e8b1d4',
    chain: 'ethereum',
    token: 'WETH',
    amount: 45000,
    valueUsd: 162000000,
    gasFee: 0.0841,
    protocol: 'Aave V3',
    method: 'flashLoanSimple()',
    block: 21847102,
    category: 'ingress',
    tally: false,
    note: 'Borrowed and repaid in the same bundle (fee: 22.5 WETH).',
  },
  {
    id: 't02',
    source: 'n1',
    target: 'n3',
    txHash: '0xa83e5c1f7b2d94e06c8a3f5b1e9d7c2a4f6b8e03d5c7a9f1b3e5d7c9a2f4b6e8',
    chain: 'ethereum',
    token: 'ETH',
    amount: 8250,
    valueUsd: 29700000,
    gasFee: 0.0312,
    protocol: 'Gnosis Safe',
    method: 'execTransaction()',
    block: 21847103,
    category: 'ingress',
    note: 'Forged signature set passed quorum check during flash-loan callback.',
  },
  {
    id: 't03',
    source: 'n1',
    target: 'n3',
    txHash: '0x2d7b9f3a5c1e86d04b2f7a9c3e5d1b8f6a4c2e9d7b5f3a1c8e6d4b2f9a7c5e31',
    chain: 'ethereum',
    token: 'USDT',
    amount: 64500000,
    valueUsd: 64500000,
    gasFee: 0.0187,
    protocol: 'Gnosis Safe',
    method: 'execTransaction() → transfer()',
    block: 21847103,
    category: 'ingress',
  },
  {
    id: 't04',
    source: 'n1',
    target: 'n3',
    txHash: '0x9c4e1a7f3b5d28e06a9c4f1b7d3e5a8c2f6b9d4e1a7c3f5b8d2e6a9c4f1b7d36',
    chain: 'ethereum',
    token: 'USDC',
    amount: 21300000,
    valueUsd: 21300000,
    gasFee: 0.0179,
    protocol: 'Gnosis Safe',
    method: 'execTransaction() → transfer()',
    block: 21847104,
    category: 'ingress',
  },
  {
    id: 't05',
    source: 'n3',
    target: 'n2',
    txHash: '0x6b1f8d4a2e7c93f05b6d1a8e4c2f7b9d3a5e1c6f8b4d2a7e9c3f5b1d6a8e4c27',
    chain: 'ethereum',
    token: 'ETH',
    amount: 8250,
    valueUsd: 29700000,
    gasFee: 0.0094,
    protocol: 'Exploit Contract',
    method: 'sweep()',
    block: 21847110,
    category: 'ingress',
    tally: false,
  },
  {
    id: 't06',
    source: 'n3',
    target: 'n2',
    txHash: '0xe5a2c8f4b1d76e03a5c2f8b4d1e7a6c3f9b5d2e8a4c1f7b3d6e9a5c2f8b4d1e7',
    chain: 'ethereum',
    token: 'USDT',
    amount: 64500000,
    valueUsd: 64500000,
    gasFee: 0.0081,
    protocol: 'Exploit Contract',
    method: 'sweep()',
    block: 21847110,
    category: 'ingress',
    tally: false,
  },
  {
    id: 't07',
    source: 'n3',
    target: 'n2',
    txHash: '0x3f8c5b2e9a1d47f06c3b8e5a2d9f1c7b4e6a3d8f5c2b9e1a7d4f6c3b8e5a2d94',
    chain: 'ethereum',
    token: 'USDC',
    amount: 21300000,
    valueUsd: 21300000,
    gasFee: 0.0083,
    protocol: 'Exploit Contract',
    method: 'sweep()',
    block: 21847111,
    category: 'ingress',
    tally: false,
  },
  {
    id: 't08',
    source: 'n2',
    target: 'n5',
    txHash: '0x7a3d9e5c1f8b26a04d7e3c9f5b1a8d6e2c4f7b9a3d5e1c8f6b2a4d7e9c3f5b18',
    chain: 'ethereum',
    token: 'USDT',
    amount: 30000000,
    valueUsd: 30000000,
    gasFee: 0.0426,
    protocol: 'Uniswap V3',
    method: 'exactInputSingle()',
    block: 21847240,
    category: 'swapped',
    note: 'Received 8,310.4 WETH.',
  },
  {
    id: 't09',
    source: 'n2',
    target: 'n11',
    txHash: '0xc1e7b3f9a5d28c04e1b7f3a9d5c2e8b6f4a1d7c3e9b5f2a8d6c4e1b7f3a9d5c2',
    chain: 'ethereum',
    token: 'USDT',
    amount: 16300000,
    valueUsd: 16300000,
    gasFee: 0.0211,
    protocol: 'Celer cBridge',
    method: 'send()',
    block: 21847380,
    category: 'mixer',
  },
  {
    id: 't10',
    source: 'n11',
    target: 'n13',
    txHash: '0x5d2a8f4c1e9b73d06a5f2c8e4b1d9a7f3c6e2b8d5a1f4c9e7b3d6a2f8c5e1b94',
    chain: 'bnb',
    token: 'USDT',
    amount: 16300000,
    valueUsd: 16300000,
    gasFee: 0.0019,
    protocol: 'Celer cBridge',
    method: 'relay()',
    block: 21847398,
    category: 'mixer',
    tally: false,
  },
  {
    id: 't11',
    source: 'n2',
    target: 'n15',
    txHash: '0xb8f4d1a7e3c95b02f8d4a1e7c3b9f5d2a6e8c4b1f7d3a9e5c2b8f4d6a1e7c3b5',
    chain: 'ethereum',
    token: 'ETH',
    amount: 3000,
    valueUsd: 10800000,
    gasFee: 0.0138,
    protocol: 'Arbitrum Bridge',
    method: 'depositEth()',
    block: 21847420,
    category: 'mixer',
  },
  {
    id: 't12',
    source: 'n15',
    target: 'n16',
    txHash: '0x1a6e3c9f5b2d84a07e1c6f3b9d5a2e8c4f7b1d6a3e9c5f2b8d4a7e1c6f3b9d52',
    chain: 'arbitrum',
    token: 'ETH',
    amount: 3000,
    valueUsd: 10800000,
    gasFee: 0.00041,
    protocol: 'Arbitrum Bridge',
    method: 'L2 retryable redeem',
    block: 21847455,
    category: 'mixer',
    tally: false,
  },
  {
    id: 't13',
    source: 'n2',
    target: 'n19',
    txHash: '0xf2c8a4e1b7d39f05c2a8e4b1d7f3c9a6e5b2d8f4a1c7e3b9d6f2a8c5e1b4d7a3',
    chain: 'ethereum',
    token: 'USDC',
    amount: 21300000,
    valueUsd: 21300000,
    gasFee: 0.0244,
    protocol: 'Wormhole',
    method: 'transferTokens()',
    block: 21847500,
    category: 'mixer',
  },
  {
    id: 't14',
    source: 'n19',
    target: 'n20',
    txHash: '5Kq9wRzT3nYb7HmP2sXc8VdF4jL6aE1uG9oKiZ3wQxB5NtMfR7yUc2pDh8vJs4eWgA6nLkT1qZ9bX3mC5rY8uP2o',
    chain: 'solana',
    token: 'USDC',
    amount: 21300000,
    valueUsd: 21300000,
    gasFee: 0.000025,
    protocol: 'Wormhole',
    method: 'completeTransfer',
    block: 21847533,
    category: 'mixer',
    tally: false,
  },
  {
    id: 't15',
    source: 'n2',
    target: 'n7',
    txHash: '0x8e4b1d7a3f9c65e02b8d4a1f7c3e9b5d2a6f8c4e1b7d3a9f5c2e8b6d4a1f7c3e',
    chain: 'ethereum',
    token: 'USDT',
    amount: 18200000,
    valueUsd: 18200000,
    gasFee: 0.0062,
    protocol: 'Tether',
    method: 'addBlackList(address)',
    block: 21847605,
    category: 'frozen',
    note: 'Executed by Tether multisig. Balance permanently frozen pending destroyBlackFunds().',
  },
  {
    id: 't16',
    source: 'n16',
    target: 'n17',
    txHash: '0x4c9f5b2e8a1d73c06f4b9e5a2d8c1f7b3e6a9d5c2f8b4e1a7d3c9f6b2e8a5d1c',
    chain: 'arbitrum',
    token: 'ETH',
    amount: 1800,
    valueUsd: 6480000,
    gasFee: 0.00092,
    protocol: 'Camelot',
    method: 'swapExactETHForTokens()',
    block: 21847700,
    category: 'swapped',
    note: 'Received 4.21M ARB + 1.9M USDC across 6 swaps.',
  },
  {
    id: 't17',
    source: 'n13',
    target: 'n12',
    txHash: '0xd6a2e8c4f1b97d05a6e2c8f4b1d9a3e7c5f2b8d6a4e1c9f7b3d5a2e8c6f4b1d9',
    chain: 'bnb',
    token: 'USDT',
    amount: 9000000,
    valueUsd: 9000000,
    gasFee: 0.0041,
    protocol: 'PancakeSwap V3',
    method: 'exactInput()',
    block: 21847800,
    category: 'swapped',
    note: 'Received 14,062 BNB.',
  },
  {
    id: 't18',
    source: 'n2',
    target: 'n8',
    txHash: '0x2b7f3d9a5e1c84b06d2f7a3e9c5b1d8f4a6e2c7b3f9d5a1e8c4b6f2d7a3e9c51',
    chain: 'ethereum',
    token: 'ETH',
    amount: 4200,
    valueUsd: 15120000,
    gasFee: 0.1932,
    protocol: 'Tornado Cash',
    method: 'deposit() ×42',
    block: 21847900,
    category: 'mixer',
    note: '42 × 100 ETH notes.',
  },
  {
    id: 't19',
    source: 'n20',
    target: 'n21',
    txHash: '3Hn8vYcT2pWb6KmR9sXd4FgL7jA1qE5uZ3oNiB8wCxM2tPfV6yUr9kDh4eJs7aGgQ5nLzT2bW8mX1cR4uY9pK3o',
    chain: 'solana',
    token: 'USDC',
    amount: 6000000,
    valueUsd: 6000000,
    gasFee: 0.000085,
    protocol: 'Jupiter',
    method: 'sharedAccountsRoute',
    block: 21848000,
    category: 'swapped',
    note: 'Received ~28,571 SOL via Orca + Raydium.',
  },
  {
    id: 't20',
    source: 'n8',
    target: 'n9',
    txHash: '0x9f5c2a8e4b1d67f03c9a5e2b8d4f1c7a3e6b9d5f2a8c4e1b7d3f9a6c2e5b8d4f',
    chain: 'ethereum',
    token: 'ETH',
    amount: 3900,
    valueUsd: 14040000,
    gasFee: 0.1716,
    protocol: 'Tornado Cash',
    method: 'withdraw() ×39',
    block: 21848300,
    category: 'mixer',
    tally: false,
    note: 'Linked via relayer reuse and withdrawal timing clusters.',
  },
  {
    id: 't21',
    source: 'n20',
    target: 'n22',
    txHash: '4Tm7wXbR1nZc5HkP8sYd3VfG6jK2aE9uL4oMiQ7wBxN1tSfC5yRr8pFh3vDs6eUgA2nJkW9qX4bT7mZ3cV6uY1o',
    chain: 'solana',
    token: 'USDC',
    amount: 15300000,
    valueUsd: 15300000,
    gasFee: 0.000005,
    protocol: 'Circle',
    method: 'freezeAccount',
    block: 21848700,
    category: 'frozen',
    note: 'Circle exercised freeze authority on the exploiter token account.',
  },
  {
    id: 't22',
    source: 'n13',
    target: 'n14',
    txHash: '0x7e3b9d5a1f6c82e04b7d3a9f5c1e8b6d2a4f7c3e9b5d1a8f6c2e4b7d3a9f5c18',
    chain: 'bnb',
    token: 'USDT',
    amount: 7300000,
    valueUsd: 7300000,
    gasFee: 0.0011,
    protocol: 'Binance Security',
    method: 'internal clawback',
    block: 21849100,
    category: 'seized',
    note: 'Deposit attributed to the exploiter; account frozen and funds rescued.',
  },
  {
    id: 't23',
    source: 'n9',
    target: 'n18',
    txHash: '0x5a1d7f3c9e6b48a02d5f1c7a3e9b6d4f8c2a5e1b7d3f9c6a4e8b2d5f1c7a3e96',
    chain: 'ethereum',
    token: 'ETH',
    amount: 1150,
    valueUsd: 4140000,
    gasFee: 0.0024,
    protocol: 'US DOJ',
    method: 'seizure warrant transfer',
    block: 21849500,
    category: 'seized',
    note: 'Executed after hop-wallet key recovery from seized device.',
  },
]

export const milestones: Milestone[] = [
  { id: 'm1', label: 'Flash Loan Injection', block: 21847102, category: 'ingress', description: '45,000 WETH borrowed from Aave V3.' },
  { id: 'm2', label: 'Initial Exploit', block: 21847103, category: 'ingress', description: 'Hot Wallet 7 drained of ETH, USDT and USDC.' },
  { id: 'm3', label: 'DEX Dump', block: 21847240, category: 'swapped', description: '30M USDT market-sold on Uniswap V3.' },
  { id: 'm4', label: 'Cross-Chain Bridging', block: 21847380, category: 'mixer', description: 'Funds split across Celer, Arbitrum and Wormhole.' },
  { id: 'm5', label: 'Freeze Execution', block: 21847605, category: 'frozen', description: 'Tether blacklists Exploiter EOA 1.' },
  { id: 'm6', label: 'Mixer Deposit', block: 21847900, category: 'mixer', description: '4,200 ETH deposited into Tornado Cash.' },
  { id: 'm7', label: 'Circle Freeze', block: 21848700, category: 'frozen', description: 'Circle freezes 15.3M USDC on Solana.' },
  { id: 'm8', label: 'Binance Clawback', block: 21849100, category: 'seized', description: '7.3M USDT rescued on BNB Chain.' },
  { id: 'm9', label: 'DOJ Seizure', block: 21849500, category: 'seized', description: '1,150 ETH seized from mixer hop wallet.' },
]

export const assets: AssetRow[] = [
  { token: 'ETH', name: 'Ether', priceUsd: 3600, stolen: 8250, converted: 1800, frozen: 0, seized: 1150 },
  { token: 'USDT', name: 'Tether USD', priceUsd: 1, stolen: 64500000, converted: 39000000, frozen: 18200000, seized: 7300000 },
  { token: 'USDC', name: 'USD Coin', priceUsd: 1, stolen: 21300000, converted: 6000000, frozen: 15300000, seized: 0 },
]

export function blockToTimestamp(block: number): string {
  const start = Date.parse(incident.startTimestamp)
  return new Date(start + (block - incident.startBlock) * incident.secondsPerBlock * 1000).toISOString()
}

export function explorerTxUrl(chain: Chain, hash: string): string {
  switch (chain) {
    case 'ethereum':
      return `https://etherscan.io/tx/${hash}`
    case 'arbitrum':
      return `https://arbiscan.io/tx/${hash}`
    case 'bnb':
      return `https://bscscan.com/tx/${hash}`
    case 'solana':
      return `https://solscan.io/tx/${hash}`
  }
}

export function explorerAddressUrl(chain: Chain, address: string): string {
  switch (chain) {
    case 'ethereum':
      return `https://etherscan.io/address/${address}`
    case 'arbitrum':
      return `https://arbiscan.io/address/${address}`
    case 'bnb':
      return `https://bscscan.com/address/${address}`
    case 'solana':
      return `https://solscan.io/account/${address}`
  }
}

export function explorerName(chain: Chain): string {
  return { ethereum: 'Etherscan', arbitrum: 'Arbiscan', bnb: 'BscScan', solana: 'Solscan' }[chain]
}
