'use client'

import { chains, entities, type Category, type Chain } from '@/data/investigationData'
import { CATEGORY_META, CATEGORY_ORDER, formatUsd } from '@/lib/forensics'
import { cn } from '@/lib/utils'
import { entityById, useInvestigation } from './investigation-provider'

export function FlowExplorer() {
  const { derived, chainFilter, setChainFilter } = useInvestigation()
  const visible = derived.visibleTransfers

  const matrix: Record<string, number> = {}
  let maxCell = 0
  for (const t of visible) {
    const key = `${entityById[t.source].chain}:${entityById[t.target].chain}`
    matrix[key] = (matrix[key] ?? 0) + t.valueUsd
    maxCell = Math.max(maxCell, matrix[key])
  }

  const chainStats = chains.map((c) => {
    const touching = visible.filter((t) => entityById[t.target].chain === c.id)
    const byCategory = CATEGORY_ORDER.reduce(
      (acc, cat) => ({
        ...acc,
        [cat]: touching.filter((t) => t.category === cat && t.tally !== false).reduce((s, t) => s + t.valueUsd, 0),
      }),
      {} as Record<Category, number>,
    )
    const categorySum = Object.values(byCategory).reduce((s, v) => s + v, 0)
    return {
      ...c,
      inflow: touching.reduce((s, t) => s + t.valueUsd, 0),
      txCount: touching.length,
      entityCount: entities.filter((e) => e.chain === c.id).length,
      tokens: [...new Set(touching.map((t) => t.token))],
      byCategory,
      categorySum,
    }
  })

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-4">
        {chainStats.map((c) => {
          const active = chainFilter === c.id
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => setChainFilter(active ? null : (c.id as Chain))}
              aria-pressed={active}
              className={cn(
                'flex flex-col gap-3 rounded-md border bg-background/60 p-4 text-left transition-colors',
                active ? 'border-seized/60 glow-seized' : 'border-border hover:border-muted-foreground/40',
              )}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-foreground">{c.label}</span>
                <span className="font-mono text-[10px] text-muted-foreground">
                  {active ? 'FILTERING · CLICK TO CLEAR' : 'CLICK TO FOCUS'}
                </span>
              </div>
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-foreground">{formatUsd(c.inflow)}</p>
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  Gross tx volume received (incl. hops)
                </p>
              </div>
              <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-muted" aria-hidden="true">
                {CATEGORY_ORDER.map((cat) =>
                  c.byCategory[cat] > 0 ? (
                    <span
                      key={cat}
                      className={CATEGORY_META[cat].dot}
                      style={{ width: `${(c.byCategory[cat] / c.categorySum) * 100}%` }}
                    />
                  ) : null,
                )}
              </div>
              <dl className="grid grid-cols-3 gap-2 font-mono text-[10px] uppercase tracking-wider">
                <div>
                  <dt className="text-muted-foreground">Txs</dt>
                  <dd className="text-foreground">{c.txCount}</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Entities</dt>
                  <dd className="text-foreground">{c.entityCount}</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Tokens</dt>
                  <dd className="truncate text-foreground">{c.tokens.join(', ') || '—'}</dd>
                </div>
              </dl>
            </button>
          )
        })}
      </div>

      <div className="overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[560px] font-mono text-xs">
          <caption className="border-b border-border px-4 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">
            Cross-chain movement matrix (source chain → destination chain, USD)
          </caption>
          <thead>
            <tr className="border-b border-border">
              <th scope="col" className="px-4 py-2 text-left text-[10px] font-normal uppercase text-muted-foreground">
                From \ To
              </th>
              {chains.map((c) => (
                <th key={c.id} scope="col" className="px-4 py-2 text-right text-[10px] font-normal uppercase text-muted-foreground">
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {chains.map((from) => (
              <tr key={from.id} className="border-b border-border last:border-b-0">
                <th scope="row" className="px-4 py-2.5 text-left font-semibold text-foreground">
                  {from.label}
                </th>
                {chains.map((to) => {
                  const value = matrix[`${from.id}:${to.id}`] ?? 0
                  const cross = from.id !== to.id
                  const intensity = maxCell ? value / maxCell : 0
                  return (
                    <td
                      key={to.id}
                      className={cn(
                        'px-4 py-2.5 text-right tabular-nums',
                        value === 0 ? 'text-muted-foreground/40' : cross ? 'text-mixer' : 'text-foreground',
                      )}
                      style={
                        value
                          ? {
                              backgroundColor: cross
                                ? `color-mix(in srgb, var(--mixer) ${Math.round(8 + intensity * 30)}%, transparent)`
                                : `color-mix(in srgb, var(--foreground) ${Math.round(2 + intensity * 8)}%, transparent)`,
                            }
                          : undefined
                      }
                    >
                      {value ? formatUsd(value) : '—'}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
