'use client'

import { Search, X } from 'lucide-react'
import { incident } from '@/data/investigationData'
import { formatBlock } from '@/lib/forensics'
import { cn } from '@/lib/utils'
import { useInvestigation, type ViewMode } from './investigation-provider'

const VIEWS: { id: ViewMode; label: string; dot: string }[] = [
  { id: 'overview', label: 'Overview', dot: 'bg-foreground' },
  { id: 'freeze', label: 'Freeze Routes', dot: 'bg-frozen' },
  { id: 'swaps', label: 'DEX Swaps', dot: 'bg-swapped' },
  { id: 'seized', label: 'Seized Assets', dot: 'bg-seized' },
]

export function DashboardHeader() {
  const { view, setView, search, setSearch, derived } = useInvestigation()

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1600px] flex-col gap-3 px-4 py-3 lg:flex-row lg:items-center lg:gap-6">
        <div className="flex min-w-0 flex-col gap-1">
          <h1 className="truncate font-mono text-sm font-bold tracking-wider text-foreground md:text-base">
            {incident.name.toUpperCase()} <span className="text-muted-foreground">— ON-CHAIN ANALYSIS</span>
          </h1>
          <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] tracking-wide">
            <span className="inline-flex items-center gap-2 rounded-sm border border-ingress/40 bg-ingress/10 px-2 py-0.5 text-ingress">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-ingress opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-ingress" />
              </span>
              {incident.status}
            </span>
            <span className="text-muted-foreground">
              {incident.dateLabel} · BLOCKS {formatBlock(incident.startBlock)} – {formatBlock(incident.endBlock)}
            </span>
            <span className="hidden text-muted-foreground/70 md:inline">CASE {incident.caseId}</span>
          </div>
        </div>

        <nav
          role="tablist"
          aria-label="View mode"
          className="flex shrink-0 gap-1 overflow-x-auto rounded-md border border-border bg-panel p-1 lg:ml-auto"
        >
          {VIEWS.map((v) => (
            <button
              key={v.id}
              type="button"
              role="tab"
              aria-selected={view === v.id}
              onClick={() => setView(v.id)}
              className={cn(
                'inline-flex items-center gap-2 whitespace-nowrap rounded-sm px-3 py-1.5 font-mono text-xs transition-colors',
                view === v.id
                  ? 'bg-accent text-foreground'
                  : 'text-muted-foreground hover:bg-accent/60 hover:text-foreground',
              )}
            >
              <span className={cn('size-1.5 rounded-full', v.dot)} aria-hidden="true" />
              {v.label}
            </button>
          ))}
        </nav>

        <div className="relative w-full lg:w-96">
          <label htmlFor="global-search" className="sr-only">
            Search wallet address, tx hash, or token ticker
          </label>
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <input
            id="global-search"
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search wallet address, tx hash, or token ticker..."
            autoComplete="off"
            spellCheck={false}
            className="h-9 w-full rounded-md border border-border bg-panel pl-9 pr-20 font-mono text-xs text-foreground placeholder:text-muted-foreground/70 focus:border-seized/60 focus:outline-none focus:ring-2 focus:ring-seized/20"
          />
          {search && (
            <div className="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1">
              <span className="font-mono text-[10px] text-muted-foreground" aria-live="polite">
                {derived.searchMatchCount} hits
              </span>
              <button
                type="button"
                onClick={() => setSearch('')}
                className="rounded-sm p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="size-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
