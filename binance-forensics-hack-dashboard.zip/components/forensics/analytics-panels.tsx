'use client'

import { useState } from 'react'
import { Activity, Network, Table } from 'lucide-react'
import { cn } from '@/lib/utils'
import { AssetBreakdown } from './asset-breakdown'
import { EventLog } from './event-log'
import { FlowExplorer } from './flow-explorer'

const TABS = [
  { id: 'flow', label: 'Flow Explorer', icon: Network },
  { id: 'assets', label: 'Asset Breakdown', icon: Table },
  { id: 'log', label: 'Live Event Log', icon: Activity },
] as const

type TabId = (typeof TABS)[number]['id']

export function AnalyticsPanels() {
  const [tab, setTab] = useState<TabId>('flow')

  return (
    <section aria-label="Analytics" className="rounded-lg border border-border bg-card/80">
      <div role="tablist" aria-label="Analytics panels" className="flex overflow-x-auto border-b border-border">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            id={`tab-${id}`}
            type="button"
            role="tab"
            aria-selected={tab === id}
            aria-controls={`panel-${id}`}
            onClick={() => setTab(id)}
            className={cn(
              '-mb-px inline-flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 font-mono text-xs transition-colors',
              tab === id
                ? 'border-seized text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground',
            )}
          >
            <Icon className="size-3.5" aria-hidden="true" />
            {label}
          </button>
        ))}
      </div>
      <div id={`panel-${tab}`} role="tabpanel" aria-labelledby={`tab-${tab}`} className="p-4">
        {tab === 'flow' && <FlowExplorer />}
        {tab === 'assets' && <AssetBreakdown />}
        {tab === 'log' && <EventLog />}
      </div>
    </section>
  )
}
