'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import {
  entities,
  incident,
  transfers,
  type Category,
  type Chain,
  type Entity,
  type Transfer,
} from '@/data/investigationData'

export type ViewMode = 'overview' | 'freeze' | 'swaps' | 'seized'
export type Selection = { type: 'node'; id: string } | { type: 'edge'; id: string } | null

export const VIEW_CATEGORY: Record<ViewMode, Category | null> = {
  overview: null,
  freeze: 'frozen',
  swaps: 'swapped',
  seized: 'seized',
}

export const pairKey = (t: Pick<Transfer, 'source' | 'target'>) => `${t.source}->${t.target}`

export const entityById: Record<string, Entity> = Object.fromEntries(entities.map((e) => [e.id, e]))

const PASS_THROUGH: Category[] = ['ingress', 'mixer']

function traceRoute(category: Category) {
  const edgeIds = new Set<string>()
  const nodeIds = new Set<string>()
  const queue: string[] = []
  for (const t of transfers) {
    if (t.category !== category) continue
    edgeIds.add(t.id)
    nodeIds.add(t.source)
    nodeIds.add(t.target)
    queue.push(t.source)
  }
  const seen = new Set<string>()
  while (queue.length) {
    const nodeId = queue.shift()!
    if (seen.has(nodeId)) continue
    seen.add(nodeId)
    for (const t of transfers) {
      if (t.target !== nodeId || !PASS_THROUGH.includes(t.category)) continue
      edgeIds.add(t.id)
      nodeIds.add(t.source)
      queue.push(t.source)
    }
  }
  return { edgeIds, nodeIds }
}

interface Derived {
  visibleTransfers: Transfer[]
  highlightedEdgeIds: Set<string>
  highlightedNodeIds: Set<string>
  reachedNodeIds: Set<string>
  feed: Transfer[]
  tallies: Record<Category, number>
  hasFilter: boolean
  searchMatchCount: number
}

interface InvestigationContextValue {
  view: ViewMode
  setView: (view: ViewMode) => void
  search: string
  setSearch: (q: string) => void
  selection: Selection
  setSelection: (s: Selection) => void
  currentBlock: number
  setCurrentBlock: (b: number) => void
  isPlaying: boolean
  togglePlay: () => void
  chainFilter: Chain | null
  setChainFilter: (c: Chain | null) => void
  derived: Derived
}

const InvestigationContext = createContext<InvestigationContextValue | null>(null)

const PLAYBACK_STEP = Math.max(1, Math.round((incident.endBlock - incident.startBlock) / 300))

export function InvestigationProvider({ children }: { children: React.ReactNode }) {
  const [view, setView] = useState<ViewMode>('overview')
  const [search, setSearch] = useState('')
  const [selection, setSelection] = useState<Selection>(null)
  const [currentBlock, setCurrentBlockState] = useState(incident.endBlock)
  const [isPlaying, setIsPlaying] = useState(false)
  const [chainFilter, setChainFilter] = useState<Chain | null>(null)

  const setCurrentBlock = useCallback((b: number) => {
    setCurrentBlockState(Math.min(incident.endBlock, Math.max(incident.startBlock, Math.round(b))))
  }, [])

  const togglePlay = useCallback(() => {
    if (!isPlaying && currentBlock >= incident.endBlock) setCurrentBlockState(incident.startBlock)
    setIsPlaying(!isPlaying)
  }, [isPlaying, currentBlock])

  useEffect(() => {
    if (!isPlaying) return
    const id = window.setInterval(() => {
      setCurrentBlockState((b) => Math.min(incident.endBlock, b + PLAYBACK_STEP))
    }, 50)
    return () => window.clearInterval(id)
  }, [isPlaying])

  useEffect(() => {
    if (isPlaying && currentBlock >= incident.endBlock) setIsPlaying(false)
  }, [isPlaying, currentBlock])

  const route = useMemo(() => {
    const category = VIEW_CATEGORY[view]
    return category ? traceRoute(category) : null
  }, [view])

  const derived = useMemo<Derived>(() => {
    const q = search.trim().toLowerCase()
    const visibleTransfers = transfers.filter((t) => t.block <= currentBlock)

    const searchNodeIds = new Set<string>()
    const searchEdgeIds = new Set<string>()
    if (q) {
      for (const e of entities) {
        if (
          e.label.toLowerCase().includes(q) ||
          e.address.toLowerCase().includes(q) ||
          e.tags.some((tag) => tag.toLowerCase().includes(q))
        ) {
          searchNodeIds.add(e.id)
        }
      }
      for (const t of transfers) {
        if (
          t.txHash.toLowerCase().includes(q) ||
          t.token.toLowerCase() === q ||
          t.token.toLowerCase().includes(q) ||
          t.protocol.toLowerCase().includes(q)
        ) {
          searchEdgeIds.add(t.id)
        }
      }
    }

    const passesEdge = (t: Transfer) => {
      if (route && !route.edgeIds.has(t.id)) return false
      if (chainFilter && entityById[t.source].chain !== chainFilter && entityById[t.target].chain !== chainFilter)
        return false
      if (q && !searchEdgeIds.has(t.id) && !searchNodeIds.has(t.source) && !searchNodeIds.has(t.target))
        return false
      return true
    }

    const highlightedEdgeIds = new Set(transfers.filter(passesEdge).map((t) => t.id))

    const highlightedNodeIds = new Set<string>()
    for (const e of entities) {
      if (route && !route.nodeIds.has(e.id)) continue
      if (chainFilter && e.chain !== chainFilter) continue
      if (q) {
        const viaEdge = transfers.some(
          (t) => searchEdgeIds.has(t.id) && (t.source === e.id || t.target === e.id),
        )
        if (!searchNodeIds.has(e.id) && !viaEdge) continue
      }
      highlightedNodeIds.add(e.id)
    }

    const reachedNodeIds = new Set<string>()
    for (const t of visibleTransfers) {
      reachedNodeIds.add(t.source)
      reachedNodeIds.add(t.target)
    }

    const feed = visibleTransfers
      .filter((t) => highlightedEdgeIds.has(t.id))
      .sort((a, b) => b.block - a.block || b.id.localeCompare(a.id))

    const tallies: Record<Category, number> = { ingress: 0, frozen: 0, swapped: 0, seized: 0, mixer: 0 }
    for (const t of visibleTransfers) {
      if (t.tally === false) continue
      tallies[t.category] += t.valueUsd
    }

    return {
      visibleTransfers,
      highlightedEdgeIds,
      highlightedNodeIds,
      reachedNodeIds,
      feed,
      tallies,
      hasFilter: Boolean(route || chainFilter || q),
      searchMatchCount: q ? searchNodeIds.size + searchEdgeIds.size : 0,
    }
  }, [search, currentBlock, route, chainFilter])

  const value = useMemo<InvestigationContextValue>(
    () => ({
      view,
      setView,
      search,
      setSearch,
      selection,
      setSelection,
      currentBlock,
      setCurrentBlock,
      isPlaying,
      togglePlay,
      chainFilter,
      setChainFilter,
      derived,
    }),
    [view, search, selection, currentBlock, setCurrentBlock, isPlaying, togglePlay, chainFilter, derived],
  )

  return <InvestigationContext.Provider value={value}>{children}</InvestigationContext.Provider>
}

export function useInvestigation() {
  const ctx = useContext(InvestigationContext)
  if (!ctx) throw new Error('useInvestigation must be used within InvestigationProvider')
  return ctx
}
