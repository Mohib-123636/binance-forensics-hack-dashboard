'use client'

import { Flag, Pause, Play, SkipBack, SkipForward } from 'lucide-react'
import { blockToTimestamp, incident, milestones, transfers } from '@/data/investigationData'
import { CATEGORY_META, formatBlock, formatDateTimeUtc } from '@/lib/forensics'
import { cn } from '@/lib/utils'
import { useInvestigation } from './investigation-provider'

const RANGE = incident.endBlock - incident.startBlock
const pct = (block: number) => ((block - incident.startBlock) / RANGE) * 100
const eventBlocks = [...new Set(transfers.map((t) => t.block))].sort((a, b) => a - b)

export function TimelineControl() {
  const { currentBlock, setCurrentBlock, isPlaying, togglePlay } = useInvestigation()

  const prevEvent = () => {
    const prev = [...eventBlocks].reverse().find((b) => b < currentBlock)
    setCurrentBlock(prev ?? incident.startBlock)
  }
  const nextEvent = () => {
    const next = eventBlocks.find((b) => b > currentBlock)
    setCurrentBlock(next ?? incident.endBlock)
  }

  const activeMilestone = [...milestones].reverse().find((m) => m.block <= currentBlock)
  const progress = pct(currentBlock)

  return (
    <section aria-label="Timeline replay" className="flex flex-col gap-3 rounded-lg border border-border bg-card/80 p-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={prevEvent}
            className="flex size-8 items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Previous event"
          >
            <SkipBack className="size-4" />
          </button>
          <button
            type="button"
            onClick={togglePlay}
            className="flex size-8 items-center justify-center rounded-md border border-seized/50 bg-seized/10 text-seized hover:bg-seized/20"
            aria-label={isPlaying ? 'Pause replay' : 'Play replay'}
          >
            {isPlaying ? <Pause className="size-4" /> : <Play className="size-4" />}
          </button>
          <button
            type="button"
            onClick={nextEvent}
            className="flex size-8 items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Next event"
          >
            <SkipForward className="size-4" />
          </button>
        </div>
        <div className="flex flex-col">
          <span className="font-mono text-sm font-semibold tabular-nums text-foreground">
            BLOCK #{formatBlock(currentBlock)}
          </span>
          <span className="font-mono text-[10px] text-muted-foreground">
            {formatDateTimeUtc(blockToTimestamp(currentBlock))} · ETH reference
          </span>
        </div>
        {activeMilestone && (
          <div className="ml-auto flex items-center gap-2 font-mono text-[11px]">
            <Flag className={cn('size-3.5', CATEGORY_META[activeMilestone.category].text)} aria-hidden="true" />
            <span className="text-foreground">{activeMilestone.label}</span>
            <span className="hidden text-muted-foreground md:inline">— {activeMilestone.description}</span>
          </div>
        )}
      </div>

      <div className="relative px-1">
        <div className="pointer-events-none absolute inset-x-1 top-1/2 h-1 -translate-y-1/2 rounded-full bg-muted">
          <div className="h-full rounded-full bg-seized/60" style={{ width: `${progress}%` }} />
          {eventBlocks.map((b) => (
            <span
              key={b}
              className={cn(
                'absolute top-1/2 h-2.5 w-px -translate-y-1/2',
                b <= currentBlock ? 'bg-foreground/50' : 'bg-foreground/15',
              )}
              style={{ left: `${pct(b)}%` }}
            />
          ))}
          {milestones.map((m) => (
            <span
              key={m.id}
              className={cn('absolute top-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rotate-45', CATEGORY_META[m.category].dot)}
              style={{ left: `${pct(m.block)}%` }}
            />
          ))}
        </div>
        <label htmlFor="timeline-scrubber" className="sr-only">
          Scrub replay block
        </label>
        <input
          id="timeline-scrubber"
          type="range"
          min={incident.startBlock}
          max={incident.endBlock}
          step={1}
          value={currentBlock}
          onChange={(e) => setCurrentBlock(Number(e.target.value))}
          className="timeline-range relative block w-full"
          aria-valuetext={`Block ${formatBlock(currentBlock)}`}
        />
      </div>

      <ol className="flex gap-2 overflow-x-auto pb-1" aria-label="Milestones">
        {milestones.map((m) => {
          const meta = CATEGORY_META[m.category]
          const reached = m.block <= currentBlock
          const isActive = activeMilestone?.id === m.id
          return (
            <li key={m.id} className="shrink-0">
              <button
                type="button"
                onClick={() => setCurrentBlock(m.block)}
                className={cn(
                  'flex flex-col items-start gap-0.5 rounded-md border px-3 py-1.5 text-left transition-colors',
                  isActive ? cn(meta.border, meta.bg) : 'border-border hover:bg-accent',
                  !reached && 'opacity-50',
                )}
              >
                <span className="flex items-center gap-1.5 font-mono text-[11px] text-foreground">
                  <span className={cn('size-1.5 rotate-45', meta.dot)} aria-hidden="true" />
                  {m.label}
                </span>
                <span className="font-mono text-[10px] text-muted-foreground">#{formatBlock(m.block)}</span>
              </button>
            </li>
          )
        })}
      </ol>
    </section>
  )
}
