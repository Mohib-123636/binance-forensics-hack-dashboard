'use client'

import { memo } from 'react'
import { Handle, Position, type Node, type NodeProps } from '@xyflow/react'
import {
  ArrowLeftRight,
  Cable,
  FileCode,
  Landmark,
  Shuffle,
  Snowflake,
  Vault,
  Wallet,
  Zap,
  type LucideIcon,
} from 'lucide-react'
import type { Chain, Entity, EntityKind } from '@/data/investigationData'
import { CATEGORY_META, CHAIN_LABEL, shortHash } from '@/lib/forensics'
import { cn } from '@/lib/utils'

const KIND_ICON: Record<EntityKind, LucideIcon> = {
  exchange: Landmark,
  wallet: Wallet,
  contract: FileCode,
  protocol: Zap,
  dex: ArrowLeftRight,
  bridge: Cable,
  mixer: Shuffle,
  issuer: Snowflake,
  vault: Vault,
}

export type EntityNodeData = {
  entity: Entity
  dimmed: boolean
  pending: boolean
  selected: boolean
}

export type EntityFlowNode = Node<EntityNodeData, 'entity'>

export const EntityNode = memo(function EntityNode({ data }: NodeProps<EntityFlowNode>) {
  const { entity, dimmed, pending, selected } = data
  const meta = CATEGORY_META[entity.category]
  const Icon = KIND_ICON[entity.kind]

  return (
    <div
      className={cn(
        'w-[210px] rounded-md border bg-card px-3 py-2.5 transition-all duration-300',
        meta.border,
        selected && meta.glow,
        dimmed && 'opacity-20',
        !dimmed && pending && 'opacity-40 saturate-0',
      )}
    >
      <Handle type="target" position={Position.Left} className="!size-2 !border-0 !bg-muted-foreground" />
      <div className="flex items-center gap-2">
        <span className={cn('flex size-7 shrink-0 items-center justify-center rounded-sm', meta.bg, meta.text)}>
          <Icon className="size-4" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold leading-tight text-foreground">{entity.label}</p>
          <p className="truncate font-mono text-[10px] text-muted-foreground">{shortHash(entity.address, 8, 6)}</p>
        </div>
      </div>
      <div className="mt-2 flex items-center justify-between font-mono text-[9px] uppercase tracking-wider">
        <span className={meta.text}>{meta.short}</span>
        <span className="text-muted-foreground">
          {entity.kind} · {CHAIN_LABEL[entity.chain]}
        </span>
      </div>
      <Handle type="source" position={Position.Right} className="!size-2 !border-0 !bg-muted-foreground" />
    </div>
  )
})

export type BandNodeData = { chain: Chain; width: number; height: number; active: boolean }
export type BandFlowNode = Node<BandNodeData, 'band'>

export const BandNode = memo(function BandNode({ data }: NodeProps<BandFlowNode>) {
  return (
    <div
      className={cn(
        'pointer-events-none relative rounded-lg border border-dashed transition-opacity',
        data.active ? 'border-foreground/15 bg-foreground/[0.02]' : 'border-foreground/10 opacity-30',
      )}
      style={{ width: data.width, height: data.height }}
    >
      <span className="absolute left-3 top-2 font-mono text-[10px] font-semibold uppercase tracking-[0.3em] text-muted-foreground">
        {CHAIN_LABEL[data.chain]}
      </span>
    </div>
  )
})
