'use client'

import { ExternalLink } from 'lucide-react'
import { blockToTimestamp, explorerName, explorerTxUrl } from '@/data/investigationData'
import { CATEGORY_META, CHAIN_LABEL, formatBlock, formatNumber, formatTimeUtc, formatUsd, shortHash } from '@/lib/forensics'
import { cn } from '@/lib/utils'
import { entityById, pairKey, useInvestigation } from './investigation-provider'

export function EventLog() {
  const { derived, setSelection } = useInvestigation()

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <p className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-frozen opacity-75" />
            <span className="relative inline-flex size-2 rounded-full bg-frozen" />
          </span>
          Live feed · newest first · {derived.feed.length} tagged transactions
        </p>
      </div>

      {derived.feed.length === 0 ? (
        <p className="rounded-md border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          No transactions match the current filters at this block.
        </p>
      ) : (
        <ol className="flex max-h-[420px] flex-col overflow-y-auto rounded-md border border-border" aria-live="polite">
          {derived.feed.map((t) => {
            const meta = CATEGORY_META[t.category]
            const from = entityById[t.source]
            const to = entityById[t.target]
            return (
              <li
                key={t.id}
                className="grid grid-cols-1 gap-2 border-b border-border px-4 py-3 last:border-b-0 hover:bg-accent/40 md:grid-cols-[110px_110px_1fr_auto_auto] md:items-center md:gap-4"
              >
                <div className="flex flex-col font-mono text-[11px]">
                  <span className="text-foreground">{formatTimeUtc(blockToTimestamp(t.block))}</span>
                  <span className="text-[10px] text-muted-foreground">#{formatBlock(t.block)}</span>
                </div>
                <span
                  className={cn(
                    'inline-flex w-fit items-center gap-1.5 rounded-sm border px-2 py-0.5 font-mono text-[10px] uppercase',
                    meta.border,
                    meta.text,
                  )}
                >
                  <span className={cn('size-1.5 rounded-full', meta.dot)} aria-hidden="true" />
                  {meta.short}
                </span>
                <button
                  type="button"
                  onClick={() => setSelection({ type: 'edge', id: pairKey(t) })}
                  className="min-w-0 text-left"
                >
                  <span className="block truncate text-sm text-foreground">
                    {from.label} <span className="text-muted-foreground">{'→'}</span> {to.label}
                  </span>
                  <span className="block truncate font-mono text-[10px] text-muted-foreground">
                    {t.protocol} · {t.method} · {CHAIN_LABEL[t.chain]}
                  </span>
                </button>
                <div className="flex flex-col font-mono text-[11px] md:items-end">
                  <span className="text-foreground">
                    {formatNumber(t.amount)} {t.token}
                  </span>
                  <span className={cn('text-[10px]', meta.text)}>{formatUsd(t.valueUsd)}</span>
                </div>
                <a
                  href={explorerTxUrl(t.chain, t.txHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex w-fit items-center gap-1.5 rounded-sm px-2 py-1 font-mono text-[10px] text-seized hover:bg-seized/10"
                  aria-label={`View transaction ${shortHash(t.txHash)} on ${explorerName(t.chain)}`}
                >
                  {shortHash(t.txHash)}
                  <ExternalLink className="size-3" aria-hidden="true" />
                </a>
              </li>
            )
          })}
        </ol>
      )}
    </div>
  )
}
