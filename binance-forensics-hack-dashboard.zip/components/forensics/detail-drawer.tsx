'use client'

import { useEffect, useState } from 'react'
import { Check, Copy, ExternalLink, X } from 'lucide-react'
import {
  ETH_PRICE_USD,
  blockToTimestamp,
  explorerAddressUrl,
  explorerName,
  explorerTxUrl,
  nativeGas,
  transfers,
  type Transfer,
} from '@/data/investigationData'
import {
  CATEGORY_META,
  CHAIN_LABEL,
  formatAmount,
  formatBlock,
  formatDateTimeUtc,
  formatNumber,
  formatUsd,
  shortHash,
} from '@/lib/forensics'
import { cn } from '@/lib/utils'
import { entityById, pairKey, useInvestigation } from './investigation-provider'

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      type="button"
      onClick={() => {
        navigator.clipboard?.writeText(value)
        setCopied(true)
        window.setTimeout(() => setCopied(false), 1200)
      }}
      className="rounded-sm p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
      aria-label={`Copy ${label}`}
    >
      {copied ? <Check className="size-3.5 text-frozen" /> : <Copy className="size-3.5" />}
    </button>
  )
}

function TransferCard({ t, pending }: { t: Transfer; pending: boolean }) {
  const meta = CATEGORY_META[t.category]
  const gas = nativeGas[t.chain]
  const from = entityById[t.source]
  const to = entityById[t.target]
  return (
    <li className={cn('flex flex-col gap-2 rounded-md border border-border bg-background/60 p-3', pending && 'opacity-40')}>
      <div className="flex items-center justify-between gap-2">
        <span className={cn('inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider', meta.text)}>
          <span className={cn('size-1.5 rounded-full', meta.dot)} aria-hidden="true" />
          {meta.short}
        </span>
        <span className="font-mono text-[10px] text-muted-foreground">
          {pending ? 'NOT YET REACHED · ' : ''}#{formatBlock(t.block)}
        </span>
      </div>
      <p className="text-xs text-muted-foreground">
        <span className="text-foreground">{from.label}</span> {'→'} <span className="text-foreground">{to.label}</span>
      </p>
      <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono text-[11px]">
        <dt className="text-muted-foreground">Amount</dt>
        <dd className="text-right text-foreground">
          {formatNumber(t.amount)} {t.token}
        </dd>
        <dt className="text-muted-foreground">Value USD</dt>
        <dd className={cn('text-right', meta.text)}>{formatUsd(t.valueUsd)}</dd>
        <dt className="text-muted-foreground">Value ETH</dt>
        <dd className="text-right text-foreground">{formatNumber(t.valueUsd / ETH_PRICE_USD, 1)} Ξ</dd>
        <dt className="text-muted-foreground">Gas Fee</dt>
        <dd className="text-right text-foreground">
          {formatNumber(t.gasFee, 6)} {gas.symbol}{' '}
          <span className="text-muted-foreground">({formatUsd(t.gasFee * gas.priceUsd)})</span>
        </dd>
        <dt className="text-muted-foreground">Protocol</dt>
        <dd className="truncate text-right text-foreground">{t.protocol}</dd>
        <dt className="text-muted-foreground">Method</dt>
        <dd className="truncate text-right text-foreground">{t.method}</dd>
        <dt className="text-muted-foreground">Time</dt>
        <dd className="text-right text-foreground">{formatDateTimeUtc(blockToTimestamp(t.block)).slice(11)}</dd>
      </dl>
      {t.note && <p className="text-xs leading-relaxed text-muted-foreground">{t.note}</p>}
      <div className="flex items-center justify-between gap-2 border-t border-border pt-2">
        <span className="truncate font-mono text-[11px] text-foreground" title={t.txHash}>
          {shortHash(t.txHash, 10, 8)}
        </span>
        <div className="flex shrink-0 items-center">
          <CopyButton value={t.txHash} label="transaction hash" />
          <a
            href={explorerTxUrl(t.chain, t.txHash)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 rounded-sm px-1.5 py-1 font-mono text-[10px] text-seized hover:bg-seized/10"
          >
            {explorerName(t.chain)}
            <ExternalLink className="size-3" aria-hidden="true" />
          </a>
        </div>
      </div>
    </li>
  )
}

export function DetailDrawer() {
  const { selection, setSelection, currentBlock } = useInvestigation()

  useEffect(() => {
    if (!selection) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setSelection(null)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [selection, setSelection])

  const entity = selection?.type === 'node' ? entityById[selection.id] : null
  const related =
    selection?.type === 'node'
      ? transfers.filter((t) => t.source === selection.id || t.target === selection.id)
      : selection?.type === 'edge'
        ? transfers.filter((t) => pairKey(t) === selection.id)
        : []
  const sorted = [...related].sort((a, b) => a.block - b.block)
  const inflow = related.filter((t) => entity && t.target === entity.id).reduce((s, t) => s + t.valueUsd, 0)
  const outflow = related.filter((t) => entity && t.source === entity.id).reduce((s, t) => s + t.valueUsd, 0)

  const edgeFrom = selection?.type === 'edge' ? entityById[sorted[0]?.source] : null
  const edgeTo = selection?.type === 'edge' ? entityById[sorted[0]?.target] : null

  return (
    <aside
      aria-label="Selection details"
      aria-hidden={!selection}
      className={cn(
        'absolute inset-y-0 right-0 z-10 flex w-full flex-col border-l border-border bg-card/95 backdrop-blur-md transition-transform duration-300 sm:w-[380px]',
        selection ? 'translate-x-0' : 'pointer-events-none translate-x-full',
      )}
    >
      {selection && (
        <>
          <div className="flex items-start justify-between gap-3 border-b border-border p-4">
            <div className="min-w-0">
              <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {entity ? `${entity.kind} · ${CHAIN_LABEL[entity.chain]}` : 'Transfer Route'}
              </p>
              <h2 className="mt-1 text-balance text-base font-semibold leading-snug text-foreground">
                {entity ? entity.label : `${edgeFrom?.label} → ${edgeTo?.label}`}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setSelection(null)}
              className="rounded-sm p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              aria-label="Close details"
            >
              <X className="size-4" />
            </button>
          </div>

          <div className="flex flex-1 flex-col gap-4 overflow-y-auto p-4">
            {entity && (
              <>
                <div className="flex flex-col gap-2 rounded-md border border-border bg-background/60 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="break-all font-mono text-[11px] text-foreground">{entity.address}</span>
                    <CopyButton value={entity.address} label="address" />
                  </div>
                  <a
                    href={explorerAddressUrl(entity.chain, entity.address)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex w-fit items-center gap-1 font-mono text-[10px] text-seized hover:underline"
                  >
                    View on {explorerName(entity.chain)}
                    <ExternalLink className="size-3" aria-hidden="true" />
                  </a>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <span
                    className={cn(
                      'rounded-sm border px-2 py-0.5 font-mono text-[10px] uppercase',
                      CATEGORY_META[entity.category].border,
                      CATEGORY_META[entity.category].text,
                    )}
                  >
                    {CATEGORY_META[entity.category].label}
                  </span>
                  {entity.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-sm border border-border px-2 py-0.5 font-mono text-[10px] uppercase text-muted-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <p className="text-sm leading-relaxed text-muted-foreground">{entity.note}</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-md border border-border bg-background/60 p-3">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Inflow</p>
                    <p className="mt-1 font-mono text-base font-semibold text-foreground">{formatUsd(inflow)}</p>
                  </div>
                  <div className="rounded-md border border-border bg-background/60 p-3">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Outflow</p>
                    <p className="mt-1 font-mono text-base font-semibold text-foreground">{formatUsd(outflow)}</p>
                  </div>
                </div>
              </>
            )}

            <div className="flex flex-col gap-2">
              <h3 className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                Transactions ({sorted.length}) · {formatAmount(sorted.reduce((s, t) => s + t.valueUsd, 0))} USD
              </h3>
              <ul className="flex flex-col gap-2">
                {sorted.map((t) => (
                  <TransferCard key={t.id} t={t} pending={t.block > currentBlock} />
                ))}
              </ul>
            </div>
          </div>
        </>
      )}
    </aside>
  )
}
