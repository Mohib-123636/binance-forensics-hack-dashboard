'use client'

import { CATEGORY_META, CATEGORY_ORDER, formatUsd } from '@/lib/forensics'
import { cn } from '@/lib/utils'
import { useInvestigation } from './investigation-provider'

export function StatsStrip() {
  const { derived } = useInvestigation()
  const exploited = derived.tallies.ingress || 1

  return (
    <section aria-label="Fund flow totals at current block" className="grid grid-cols-2 gap-2 md:grid-cols-5">
      {CATEGORY_ORDER.map((category) => {
        const meta = CATEGORY_META[category]
        const value = derived.tallies[category]
        const share = category === 'ingress' ? 100 : Math.min(100, (value / exploited) * 100)
        return (
          <div key={category} className="flex flex-col gap-2 rounded-md border border-border bg-card/80 p-3">
            <div className="flex items-center gap-2">
              <span className={cn('size-2 rounded-full', meta.dot)} aria-hidden="true" />
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {meta.label}
              </span>
            </div>
            <p className={cn('font-mono text-xl font-semibold tabular-nums', meta.text)}>{formatUsd(value)}</p>
            <div className="h-1 w-full overflow-hidden rounded-full bg-muted" aria-hidden="true">
              <div className={cn('h-full rounded-full transition-all', meta.dot)} style={{ width: `${share}%` }} />
            </div>
          </div>
        )
      })}
    </section>
  )
}
