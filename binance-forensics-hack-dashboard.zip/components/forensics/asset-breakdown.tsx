'use client'

import { Download, FileSpreadsheet } from 'lucide-react'
import { assets, incident } from '@/data/investigationData'
import { formatNumber, formatUsd } from '@/lib/forensics'
import { cn } from '@/lib/utils'

const rows = assets.map((a) => {
  const unsecured = Math.max(0, a.stolen - a.frozen - a.seized)
  return { ...a, unsecured, recoveryRate: a.stolen ? ((a.frozen + a.seized) / a.stolen) * 100 : 0 }
})

const totals = rows.reduce(
  (acc, r) => ({
    stolen: acc.stolen + r.stolen * r.priceUsd,
    converted: acc.converted + r.converted * r.priceUsd,
    frozen: acc.frozen + r.frozen * r.priceUsd,
    seized: acc.seized + r.seized * r.priceUsd,
    unsecured: acc.unsecured + r.unsecured * r.priceUsd,
  }),
  { stolen: 0, converted: 0, frozen: 0, seized: 0, unsecured: 0 },
)

const COLUMNS = [
  { key: 'stolen', label: 'Stolen', text: 'text-ingress' },
  { key: 'converted', label: 'Converted', text: 'text-swapped' },
  { key: 'frozen', label: 'Frozen', text: 'text-frozen' },
  { key: 'seized', label: 'Seized', text: 'text-seized' },
  { key: 'unsecured', label: 'Unsecured', text: 'text-foreground' },
] as const

const HEADER = ['Token', 'Name', 'Price USD', ...COLUMNS.flatMap((c) => [`${c.label} (units)`, `${c.label} (USD)`]), 'Recovery %']

function tableRows(): (string | number)[][] {
  return rows.map((r) => [
    r.token,
    r.name,
    r.priceUsd,
    ...COLUMNS.flatMap((c) => [r[c.key], r[c.key] * r.priceUsd]),
    Number(r.recoveryRate.toFixed(2)),
  ])
}

function download(content: string, filename: string, type: string) {
  const blob = new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function exportCsv() {
  const escape = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`
  const csv = [HEADER, ...tableRows()].map((row) => row.map(escape).join(',')).join('\n')
  download(csv, `${incident.caseId}-asset-breakdown.csv`, 'text/csv;charset=utf-8')
}

function exportExcel() {
  const escapeXml = (v: string | number) =>
    String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  const cell = (v: string | number) =>
    `<Cell><Data ss:Type="${typeof v === 'number' ? 'Number' : 'String'}">${escapeXml(v)}</Data></Cell>`
  const xml = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="Asset Breakdown"><Table>
${[HEADER, ...tableRows()].map((row) => `<Row>${row.map(cell).join('')}</Row>`).join('\n')}
</Table></Worksheet></Workbook>`
  download(xml, `${incident.caseId}-asset-breakdown.xls`, 'application/vnd.ms-excel')
}

export function AssetBreakdown() {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          Snapshot at block #{formatNumber(incident.endBlock)} · Unsecured = Stolen − Frozen − Seized
        </p>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={exportCsv}
            className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-1.5 font-mono text-xs text-foreground hover:bg-accent"
          >
            <Download className="size-3.5" aria-hidden="true" />
            Export CSV
          </button>
          <button
            type="button"
            onClick={exportExcel}
            className="inline-flex items-center gap-2 rounded-md border border-frozen/50 bg-frozen/10 px-3 py-1.5 font-mono text-xs text-frozen hover:bg-frozen/20"
          >
            <FileSpreadsheet className="size-3.5" aria-hidden="true" />
            Export Excel
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[760px] font-mono text-xs">
          <thead>
            <tr className="border-b border-border bg-background/60">
              <th scope="col" className="px-4 py-2.5 text-left text-[10px] font-normal uppercase tracking-wider text-muted-foreground">
                Token
              </th>
              {COLUMNS.map((c) => (
                <th
                  key={c.key}
                  scope="col"
                  className={cn('px-4 py-2.5 text-right text-[10px] font-normal uppercase tracking-wider', c.text)}
                >
                  {c.label}
                </th>
              ))}
              <th scope="col" className="px-4 py-2.5 text-right text-[10px] font-normal uppercase tracking-wider text-muted-foreground">
                Recovery
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.token} className="border-b border-border hover:bg-accent/40">
                <th scope="row" className="px-4 py-3 text-left">
                  <span className="block font-semibold text-foreground">{r.token}</span>
                  <span className="text-[10px] font-normal text-muted-foreground">{r.name}</span>
                </th>
                {COLUMNS.map((c) => (
                  <td key={c.key} className="px-4 py-3 text-right tabular-nums">
                    <span className="block text-foreground">{formatNumber(r[c.key], 0)}</span>
                    <span className="text-[10px] text-muted-foreground">{formatUsd(r[c.key] * r.priceUsd)}</span>
                  </td>
                ))}
                <td className="px-4 py-3 text-right">
                  <div className="ml-auto flex w-28 flex-col items-end gap-1">
                    <span className="tabular-nums text-foreground">{r.recoveryRate.toFixed(1)}%</span>
                    <span className="flex h-1 w-full overflow-hidden rounded-full bg-muted" aria-hidden="true">
                      <span className="bg-frozen" style={{ width: `${(r.frozen / r.stolen) * 100}%` }} />
                      <span className="bg-seized" style={{ width: `${(r.seized / r.stolen) * 100}%` }} />
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-background/60">
              <th scope="row" className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                Total (USD)
              </th>
              {COLUMNS.map((c) => (
                <td key={c.key} className={cn('px-4 py-3 text-right text-sm font-semibold tabular-nums', c.text)}>
                  {formatUsd(totals[c.key])}
                </td>
              ))}
              <td className="px-4 py-3 text-right text-sm font-semibold tabular-nums text-foreground">
                {(((totals.frozen + totals.seized) / totals.stolen) * 100).toFixed(1)}%
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}
