'use client'

import { useCallback, useMemo } from 'react'
import {
  Background,
  BackgroundVariant,
  MarkerType,
  Panel,
  ReactFlow,
  ReactFlowProvider,
  useNodesState,
  useReactFlow,
  type Edge,
  type Node,
  type NodeTypes,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { Maximize, Minus, Plus, RotateCcw } from 'lucide-react'
import { bandWidth, bandX, chainBands, entities, transfers, type Transfer } from '@/data/investigationData'
import { CATEGORY_META, formatUsd } from '@/lib/forensics'
import { BandNode, EntityNode, type BandFlowNode, type EntityFlowNode } from './canvas-nodes'
import { DetailDrawer } from './detail-drawer'
import { pairKey, useInvestigation } from './investigation-provider'

const nodeTypes: NodeTypes = { entity: EntityNode, band: BandNode }

const RECENT_WINDOW = 160

const initialNodes: EntityFlowNode[] = entities.map((entity) => ({
  id: entity.id,
  type: 'entity',
  position: entity.position,
  data: { entity, dimmed: false, pending: false, selected: false },
}))

const transferPairs = (() => {
  const map = new Map<string, Transfer[]>()
  for (const t of transfers) {
    const key = pairKey(t)
    map.set(key, [...(map.get(key) ?? []), t])
  }
  return [...map.entries()]
})()

function CanvasControls() {
  const { zoomIn, zoomOut, fitView, setNodes } = useReactFlow()

  const resetLayout = useCallback(() => {
    setNodes((nodes) =>
      nodes.map((n) => {
        const original = initialNodes.find((i) => i.id === n.id)
        return original ? { ...n, position: original.position } : n
      }),
    )
    requestAnimationFrame(() => fitView({ padding: 0.08, duration: 400 }))
  }, [setNodes, fitView])

  const buttons = [
    { label: 'Zoom in', icon: Plus, onClick: () => zoomIn({ duration: 200 }) },
    { label: 'Zoom out', icon: Minus, onClick: () => zoomOut({ duration: 200 }) },
    { label: 'Fit to screen', icon: Maximize, onClick: () => fitView({ padding: 0.08, duration: 400 }) },
    { label: 'Reset layout', icon: RotateCcw, onClick: resetLayout },
  ]

  return (
    <Panel position="bottom-left" className="!m-3">
      <div className="flex flex-col overflow-hidden rounded-md border border-border bg-card/95 backdrop-blur">
        {buttons.map(({ label, icon: Icon, onClick }) => (
          <button
            key={label}
            type="button"
            onClick={onClick}
            title={label}
            aria-label={label}
            className="flex size-9 items-center justify-center border-b border-border text-muted-foreground transition-colors last:border-b-0 hover:bg-accent hover:text-foreground"
          >
            <Icon className="size-4" />
          </button>
        ))}
      </div>
    </Panel>
  )
}

function CanvasInner() {
  const { derived, currentBlock, selection, setSelection, chainFilter, view } = useInvestigation()
  const [nodes, , onNodesChange] = useNodesState<Node>(initialNodes)

  const bandNodes = useMemo<BandFlowNode[]>(
    () =>
      chainBands.map((band) => ({
        id: `band-${band.chain}`,
        type: 'band',
        position: { x: bandX, y: band.y },
        data: { chain: band.chain, width: bandWidth, height: band.height, active: !chainFilter || chainFilter === band.chain },
        draggable: false,
        selectable: false,
        focusable: false,
        zIndex: -1,
      })),
    [chainFilter],
  )

  const renderedNodes = useMemo<Node[]>(
    () => [
      ...bandNodes,
      ...nodes.map((n) => ({
        ...n,
        data: {
          ...n.data,
          dimmed: !derived.highlightedNodeIds.has(n.id),
          pending: !derived.reachedNodeIds.has(n.id),
          selected: selection?.type === 'node' && selection.id === n.id,
        },
      })),
    ],
    [bandNodes, nodes, derived, selection],
  )

  const edges = useMemo<Edge[]>(
    () =>
      transferPairs.map(([key, group]) => {
        const visible = group.filter((t) => t.block <= currentBlock)
        const highlighted = group.some((t) => derived.highlightedEdgeIds.has(t.id))
        const meta = CATEGORY_META[group[0].category]
        const isSelected = selection?.type === 'edge' && selection.id === key
        const recent = visible.some((t) => currentBlock - t.block < RECENT_WINDOW)
        const totalUsd = visible.reduce((sum, t) => sum + t.valueUsd, 0)
        const shown = visible.length > 0
        const opacity = !shown ? 0 : highlighted ? 1 : 0.1

        return {
          id: key,
          source: group[0].source,
          target: group[0].target,
          animated: shown && (recent || isSelected),
          hidden: !shown,
          label: shown
            ? `${formatUsd(totalUsd)}${visible.length > 1 ? ` · ×${visible.length}` : ` · ${visible[0].token}`}`
            : undefined,
          style: { stroke: meta.hex, strokeWidth: isSelected ? 3 : 1.75, opacity },
          labelStyle: { fill: meta.hex, fontFamily: 'var(--font-jetbrains-mono)', fontSize: 10, fontWeight: 600, opacity },
          labelBgStyle: { fill: '#0a0a0c', fillOpacity: opacity ? 0.92 : 0, stroke: meta.hex, strokeOpacity: opacity * 0.35 },
          labelBgPadding: [6, 3] as [number, number],
          labelBgBorderRadius: 3,
          markerEnd: { type: MarkerType.ArrowClosed, color: meta.hex, width: 16, height: 16 },
          interactionWidth: 18,
        }
      }),
    [currentBlock, derived, selection],
  )

  const highlightedCount = derived.visibleTransfers.filter((t) => derived.highlightedEdgeIds.has(t.id)).length

  return (
    <ReactFlow
      nodes={renderedNodes}
      edges={edges}
      nodeTypes={nodeTypes}
      onNodesChange={onNodesChange}
      onNodeClick={(_, node) => node.type === 'entity' && setSelection({ type: 'node', id: node.id })}
      onEdgeClick={(_, edge) => setSelection({ type: 'edge', id: edge.id })}
      onPaneClick={() => setSelection(null)}
      colorMode="dark"
      fitView
      fitViewOptions={{ padding: 0.08 }}
      minZoom={0.2}
      maxZoom={2}
      proOptions={{ hideAttribution: true }}
    >
      <Background variant={BackgroundVariant.Lines} gap={40} color="rgba(255,255,255,0.03)" />
      <Panel position="top-right" className="!m-3">
        <div className="rounded-md border border-border bg-card/90 px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground backdrop-blur">
          <span className="text-foreground">{view === 'overview' ? 'Full Graph' : view}</span>
          {' · '}
          {highlightedCount}/{transfers.length} transfers
          {chainFilter && <span className="text-seized"> · {chainFilter}</span>}
        </div>
      </Panel>
      <CanvasControls />
    </ReactFlow>
  )
}

export function FlowCanvas() {
  return (
    <section
      aria-label="Fund flow network graph"
      className="relative h-[560px] overflow-hidden rounded-lg border border-border bg-panel/80 md:h-[620px]"
    >
      <ReactFlowProvider>
        <CanvasInner />
      </ReactFlowProvider>
      <DetailDrawer />
    </section>
  )
}
