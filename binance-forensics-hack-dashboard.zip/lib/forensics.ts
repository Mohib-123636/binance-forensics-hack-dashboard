import type { Category, Chain } from '@/data/investigationData'

export const CATEGORY_META: Record<
  Category,
  { label: string; short: string; hex: string; text: string; bg: string; border: string; dot: string; glow: string }
> = {
  ingress: {
    label: 'Exploited / Ingress',
    short: 'Exploited',
    hex: '#ef4444',
    text: 'text-ingress',
    bg: 'bg-ingress/10',
    border: 'border-ingress/40',
    dot: 'bg-ingress',
    glow: 'glow-ingress',
  },
  frozen: {
    label: 'Frozen / Blocked',
    short: 'Frozen',
    hex: '#10b981',
    text: 'text-frozen',
    bg: 'bg-frozen/10',
    border: 'border-frozen/40',
    dot: 'bg-frozen',
    glow: 'glow-frozen',
  },
  swapped: {
    label: 'Converted / Swapped',
    short: 'Swapped',
    hex: '#f59e0b',
    text: 'text-swapped',
    bg: 'bg-swapped/10',
    border: 'border-swapped/40',
    dot: 'bg-swapped',
    glow: 'glow-swapped',
  },
  seized: {
    label: 'Seized / Rescued',
    short: 'Seized',
    hex: '#06b6d4',
    text: 'text-seized',
    bg: 'bg-seized/10',
    border: 'border-seized/40',
    dot: 'bg-seized',
    glow: 'glow-seized',
  },
  mixer: {
    label: 'Mixer / Obfuscated Hops',
    short: 'Obfuscated',
    hex: '#8b5cf6',
    text: 'text-mixer',
    bg: 'bg-mixer/10',
    border: 'border-mixer/40',
    dot: 'bg-mixer',
    glow: 'glow-mixer',
  },
}

export const CATEGORY_ORDER: Category[] = ['ingress', 'swapped', 'mixer', 'frozen', 'seized']

export const CHAIN_LABEL: Record<Chain, string> = {
  ethereum: 'Ethereum',
  arbitrum: 'Arbitrum',
  bnb: 'BNB Chain',
  solana: 'Solana',
}

const numberFormatter = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 })
const blockFormatter = new Intl.NumberFormat('en-US')

export function formatUsd(value: number): string {
  const abs = Math.abs(value)
  if (abs >= 1e9) return `$${(value / 1e9).toFixed(2)}B`
  if (abs >= 1e6) return `$${(value / 1e6).toFixed(2)}M`
  if (abs >= 1e3) return `$${(value / 1e3).toFixed(1)}K`
  return `$${value.toFixed(2)}`
}

export function formatAmount(value: number): string {
  const abs = Math.abs(value)
  if (abs >= 1e6) return `${(value / 1e6).toFixed(2)}M`
  if (abs >= 1e4) return `${(value / 1e3).toFixed(1)}K`
  return numberFormatter.format(value)
}

export function formatNumber(value: number, maximumFractionDigits = 2): string {
  return new Intl.NumberFormat('en-US', { maximumFractionDigits }).format(value)
}

export function formatBlock(block: number): string {
  return blockFormatter.format(block)
}

export function shortHash(hash: string, lead = 6, tail = 4): string {
  if (hash.length <= lead + tail + 1) return hash
  return `${hash.slice(0, lead)}…${hash.slice(-tail)}`
}

export function formatTimeUtc(iso: string): string {
  return `${iso.slice(11, 19)} UTC`
}

export function formatDateTimeUtc(iso: string): string {
  return `${iso.slice(0, 10)} ${iso.slice(11, 19)} UTC`
}
